import React, { Component } from "react";

class Congrats extends Component {
  state = {};
  render() {
    return <div>asdasd</div>;
  }
}

export default Congrats;
