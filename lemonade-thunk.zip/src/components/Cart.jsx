import React, { Component } from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";
import {
  removeItem,
  addQuantity,
  subtractQuantity,
} from "./actions/cartActions.jsx";
import Recipe from "./Recipe.jsx";

class Cart extends Component {
  handleRemove = (id) => {
    this.props.removeItem(id);
  };
  handleAddQuantity = (id) => {
    this.props.addQuantity(id);
  };

  handleSubtractQuantity = (id) => {
    this.props.subtractQuantity(id);
  };
  render() {
    let addedItems = this.props.items.length ? (
      this.props.items.map((item) => {
        return (
          <div className="container">
            <div className="row" style={{ width: cartWidth }} key={item.id}>
              <div className="col-sm">
                <div className="item-img">
                  <img src={item.img} alt={item.img} className="" />
                </div>
              </div>
              <div className="col-sm">
                <span className="card-title">{item.title}</span>
                <p>{item.desc}</p>

                <p>
                  <b>Price: {item.price}Kronen</b>
                </p>
                <p>
                  <b>Quantity: {item.quantity}</b>
                </p>
              </div>
              <div class="col-sm">
                <div className="add-remove">
                  <Link to="/cart">
                    <i className="plus bg-light" onClick={() => { this.handleAddQuantity(item.id); }}>+</i>
                  </Link>
                  <Link to="/cart">
                    <i className="minus bg-light" onClick={() => { this.handleSubtractQuantity(item.id); }}>-</i>
                  </Link>
                </div>
                <button
                  className="btn btn-danger"
                  onClick={() => {
                    this.handleRemove(item.id);
                  }}
                >
                  Remove
                </button>
              </div>
            </div>
          </div>
        );
      })
    ) : (
      <p>U haven't choose </p>
    );
    return (
      <div className="container">
        <div className="shadow-sm p-3 mb-5 bg-white rounded">
          <h5>You have choosed:</h5>
          <ul className="collection">{addedItems}</ul>
        </div>
        <Recipe />
      </div>
    );
  }
}
const cartWidth = "95%";
const mapStateToProps = (state) => {
  return {
    items: state.addedItems,
  };
};
const mapDispatchToProps = (dispatch) => {
  return {
    removeItem: (id) => { dispatch(removeItem(id));},
    addQuantity: (id) => { dispatch(addQuantity(id));},
    subtractQuantity: (id) => { dispatch(subtractQuantity(id));},
  };
};
export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Cart);
