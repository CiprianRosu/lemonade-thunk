import React from "react";
import { Link } from "react-router-dom";
const Navbar = () => {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
      <div className="container">
        <Link to="/" className="brand-logo">
          Lemonade
        </Link>

        <div className="collapse navbar-collapse" id="navbarNav" />
        <ul className="navbar-nav">
          <li>
            <Link to="/cart">
              <i className="nav-item material-icons">shopping_cart</i>
            </Link>
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
