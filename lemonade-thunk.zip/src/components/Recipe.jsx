import React, { Component } from "react";
import { connect } from "react-redux";
import { Link } from "react-router-dom";

class Recipe extends Component {
  render() {
    return (
      <div className="container">
        <div>
          <b>Total: {this.props.total} Kornen</b>
        </div>
        <div>
          <Link to="/congrats">
            <button className="btn btn-primary">shopping_cart</button>
          </Link>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => {
  return {
    addedItems: state.addedItems,
    total: state.total,
  };
};

export default connect(mapStateToProps)(Recipe);
