import React, { Component } from "react";
import { BrowserRouter, Route, Switch } from "react-router-dom";
import Navbar from "./components/Navbar.jsx";
import Home from "./components/Home.jsx";
import Cart from "./components/Cart.jsx";
import Congrats from "./components/congrats.jsx";

class App extends Component {
  render() {
    return (
      <BrowserRouter>
        <div className="App">
          <Navbar />
          <Switch>
            <Route exact path="/" component={Home} />
            <Route path="/cart" component={Cart} />
            <Route path="/congrats" component={Congrats} />
          </Switch>
        </div>
      </BrowserRouter>
    );
  }
}

export default App;
